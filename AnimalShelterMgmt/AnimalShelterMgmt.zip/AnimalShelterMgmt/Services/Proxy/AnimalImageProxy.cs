﻿using AnimalShelterMgmt.Services.Proxy;
using System.Collections.Generic;

namespace AnimalShelterMgmt.Services.Proxy
{
    public class AnimalImageProxy : IAnimalImageProvider
    {
        private readonly IAnimalImageProvider _realService;
        private readonly Dictionary<int, string> _cache = new();

        public AnimalImageProxy(IAnimalImageProvider realService)
        {
            _realService = realService;
        }

        public string GetImageUrl(int animalId)
        {
            if (_cache.ContainsKey(animalId))
            {
                return _cache[animalId];
            }

            var imageUrl = _realService.GetImageUrl(animalId);
            _cache[animalId] = imageUrl;
            return imageUrl;
        }
    }
}
