﻿namespace AnimalShelterMgmt.Services.Proxy
{
    public interface IAnimalImageProvider
    {
        string GetImageUrl(int animalId);
    }
}
