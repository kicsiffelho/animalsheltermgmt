﻿using AnimalShelterMgmt.Models;
using AnimalShelterMgmt.Services;
using AnimalShelterMgmt.Services.Proxy;
using CommunityToolkit.Mvvm.ComponentModel;
using System.Collections.ObjectModel;

namespace AnimalShelterMgmt.ViewModels
{
    public partial class AnimalsViewModel : ObservableObject
    {
        private readonly IAnimalImageProvider _imageProvider;

        public ObservableCollection<Animal> Animals { get; } = new();

        public AnimalsViewModel()
        {
            _imageProvider = new AnimalImageProxy(new AnimalImageService());
            LoadAnimals();
        }

        public void LoadAnimals()
        {
            Animals.Clear();
            var db = new DatabaseService();

            foreach (var animal in db.GetAnimals())
            {
                animal.ImageUrl = _imageProvider.GetImageUrl(animal.Id);
                Animals.Add(animal);
            }
        }

        public void RefreshAnimals()
        {
            LoadAnimals();
        }
    }
}
