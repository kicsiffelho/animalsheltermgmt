﻿using System.Windows.Controls;

namespace AnimalShelterMgmt.Views
{
    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}