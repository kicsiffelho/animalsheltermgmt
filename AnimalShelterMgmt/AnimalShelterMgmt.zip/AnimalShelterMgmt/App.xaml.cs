﻿using AnimalShelterMgmt.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;
using Microsoft.Extensions.Logging.Debug;
using System.Configuration;
using System.Data;
using System.Windows;

namespace AnimalShelterMgmt;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{

}

